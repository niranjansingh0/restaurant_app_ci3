<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-02-08 11:01:30 --> 404 Page Not Found: Resetpasswordphp/index
