// Add to cart confirmation
function addToCart(itemName) {
    alert(itemName + " added to cart 🛒");
}

// Order placed message
function orderPlaced() {
    alert("✅ Order placed successfully!");
}

// Confirm delete (admin)
function confirmDelete() {
    return confirm("Are you sure you want to delete this item?");
}
